# Design Prompt — "Services" Section (as-is recreation)

> Copy-paste this into ChatGPT / Claude / Cursor or hand it to a developer:

Build a **Services** section for a learning-technology website with this exact design:

**Layout.** Full-width white section, 80px vertical padding, content capped at 1200px with 20px side padding. Centered heading "Services" — bold, 36px on desktop (28px mobile / 32px tablet), near-black ink color (#17172B), no underline, no badge. 48px spacing between the heading and the grid.

**Grid.** A 13-card service grid: 4 columns on desktop with 24px gap, 2 columns on tablet, 1 on mobile. The first 12 cards fill exactly 3 full rows. The 13th card sits alone in the last row, **horizontally centered**, at the same width as one column (~270px).

**Card.** White surface, 24px border radius, 1px hairline border in #ECECF3, very subtle shadow (0 1px 3px rgba(23,23,43,0.06)), 24px padding, equal heights in a row (flex column). On hover the card lifts 6px with a soft violet-tinted shadow (0 16px 32px -12px rgba(124,58,237,0.22)); 300ms ease transition.

**Card content, top to bottom:**
1. **Icon tile** — 64×64px, 16px radius, flat soft lavender-gray background (#F1F1F7) — the *same tile color on every card* — containing a ~56px colorful flat-illustration icon (vibrant purple / orange / teal palette, education + tech theme, a different illustration per card).
2. **Index number** — "01" through "13", 12px bold, violet #7C3AED.
3. **Title** — 16px bold, ink #17172B, snug leading, may wrap to two lines.
4. **Description** — 14px, muted gray #8B8B9B, 1.6 line-height, clamped to exactly 2 lines with ellipsis (line-clamp), and set to flex-grow so it pins the footer to the bottom.
5. **Arrow button** — bottom-right, 36px circle, white background, 1px #ECECF3 border, dark "→" arrow. On card hover the circle fills with a primary→purple gradient and the arrow turns white.

**Content (13 cards).** LMS Setup & Management · SCORM Module Development · Gamified Learning Modules · ILT & VILT Decks · Microlearning Nuggets · Video-Based Training · Instructional Design Consulting · Storyboarding & Script Writing · Content Conversion & Modernization · Translation & Localization · Learning Campaigns · Learning Portal Creation · Promotional & Buzz Videos — each with a 1–2 line marketing description.
