# Services Section — Integration Guide

## Files
- `Services.tsx` — drop-in Next.js (App Router) component
- `prompt.md` — the design prompt (as-is spec) you can reuse with any AI tool
- `preview.html` — live visual preview of the section (open in a browser)
- `icons/services/*.png` — the 13 flat illustration icons

## Steps
1. **Copy the icons**
   Copy the `icons/services/` folder into your Next.js app's public folder:
   ```
   /public/icons/services/lms.png  (etc.)
   ```
2. **Add the component**
   Save `Services.tsx` as e.g. `app/services/Services.tsx` and render it:
   ```tsx
   import ServicesSection from "./Services";
   // ...
   <ServicesSection />
   ```
3. **Design tokens** (already in your code, so it should just work)
   - `font-heading`, `text-ink`, `text-muted`, `card-hover`, `from-primary`, `to-purple`
   - If `card-hover` is not defined yet, add to your global CSS:
     ```css
     .card-hover { transition: transform .3s ease, box-shadow .3s ease; }
     .card-hover:hover { transform: translateY(-6px); box-shadow: 0 16px 32px -12px rgba(124, 58, 237, .22); }
     ```
4. **line-clamp-2** is built into Tailwind v3.3+ / v4. On older versions add
   `@tailwindcss/line-clamp` or `line-clamp` from `@tailwindcss/forms` plugin.
5. **Icons are optional** — if you skip the PNGs, each card automatically
   falls back to the emoji in the `SERVICES` data (🎮, 🎬, 📱, …).

## Notes vs. your current code
- Removed the `.section-underline` (the reference has no underline — re-add
  the `<div class="section-underline mt-3 mx-auto"></div>` after the `<h2>` if you want it).
- Icon tiles are now a **uniform soft lavender-gray (#F1F1F7)** on every card
  (your old code used a different pastel per card).
- Descriptions are clamped to exactly 2 lines (`line-clamp-2`) to match the
  reference; your unique per-card copy is kept.
- The 13th card is centered below the 4-column grid at single-column width
  (was spanning 4 columns before).
