/*
 * Services section — matches the reference design exactly:
 * - 4-col grid (12 cards) + 13th card centered below at single-column width
 * - Soft lavender-gray icon tiles (#F1F1F7) with colorful flat illustrations
 * - Violet index numbers (01–13), bold ink titles, 2-line clamped muted descriptions
 * - Circular → arrow button, fills with primary→purple gradient on card hover
 *
 * Uses your existing design tokens: font-heading, text-ink, text-muted,
 * card-hover, from-primary, to-purple. Swap hex values for your tokens
 * where you have equivalents.
 *
 * Icons live in /public/icons/services/*.png — if an image is missing the
 * card automatically falls back to the emoji defined in the data.
 */

type Service = {
  no: string;
  title: string;
  description: string;
  icon: string; // /public/icons/services/xxx.png
  emoji: string; // fallback if the image is not present
};

const SERVICES: Service[] = [
  {
    no: "01",
    title: "LMS Setup & Management",
    description:
      "Set up, configure, and launch your Learning Management System with seamless integrations and reporting.",
    icon: "/icons/services/lms.png",
    emoji: "🖥️",
  },
  {
    no: "02",
    title: "SCORM Module Development",
    description:
      "Interactive, standards-compliant SCORM modules that play flawlessly across every LMS.",
    icon: "/icons/services/scorm.png",
    emoji: "🧩",
  },
  {
    no: "03",
    title: "Gamified Learning Modules",
    description:
      "Game mechanics and challenges that turn passive learners into active participants.",
    icon: "/icons/services/gamified.png",
    emoji: "🎮",
  },
  {
    no: "04",
    title: "ILT & VILT Decks",
    description:
      "Facilitator-ready decks designed for engaging instructor-led and virtual classrooms.",
    icon: "/icons/services/ilt.png",
    emoji: "🎓",
  },
  {
    no: "05",
    title: "Microlearning Nuggets",
    description:
      "Bite-sized, mobile-first learning nuggets built for busy, on-the-go learners.",
    icon: "/icons/services/microlearning.png",
    emoji: "📱",
  },
  {
    no: "06",
    title: "Video-Based Training",
    description:
      "Scripted, shot, and animated training videos that simplify complex processes.",
    icon: "/icons/services/video.png",
    emoji: "🎬",
  },
  {
    no: "07",
    title: "Instructional Design Consulting",
    description:
      "Strategic guidance on learning architecture, blended pathways, and outcomes.",
    icon: "/icons/services/instructional.png",
    emoji: "💡",
  },
  {
    no: "08",
    title: "Storyboarding & Script Writing",
    description:
      "Narrative-driven storyboards and scripts that give every module a strong spine.",
    icon: "/icons/services/storyboard.png",
    emoji: "📝",
  },
  {
    no: "09",
    title: "Content Conversion & Modernization",
    description:
      "Revamp legacy PPTs and PDFs into modern, interactive digital experiences.",
    icon: "/icons/services/conversion.png",
    emoji: "🔄",
  },
  {
    no: "10",
    title: "Translation & Localization",
    description:
      "Culturally-tuned localization so your training resonates in every market.",
    icon: "/icons/services/translation.png",
    emoji: "🌐",
  },
  {
    no: "11",
    title: "Learning Campaigns",
    description:
      "End-to-end awareness and learning campaigns that drive measurable engagement.",
    icon: "/icons/services/campaigns.png",
    emoji: "🎯",
  },
  {
    no: "12",
    title: "Learning Portal Creation",
    description:
      "Branded learning portals that bring together your content in one seamless hub.",
    icon: "/icons/services/portal.png",
    emoji: "🚀",
  },
  {
    no: "13",
    title: "Promotional & Buzz Videos",
    description:
      "High-energy promotional and buzz videos that build excitement for new launches.",
    icon: "/icons/services/promo.png",
    emoji: "📣",
  },
];

function ServiceIcon({ service }: { service: Service }) {
  return (
    <div className="mb-4 flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-[#F1F1F7]">
      <img
        src={service.icon}
        alt=""
        loading="lazy"
        decoding="async"
        className="h-14 w-14 object-contain"
        onError={(e) => {
          // Fallback: swap the broken image for the emoji
          const img = e.currentTarget;
          const span = document.createElement("span");
          span.className = "text-3xl leading-none";
          span.textContent = service.emoji;
          img.replaceWith(span);
        }}
      />
    </div>
  );
}

function ServiceCard({
  service,
  className = "",
}: {
  service: Service;
  className?: string;
}) {
  return (
    <article
      className={`card-hover group flex flex-col rounded-3xl border border-[#ECECF3] bg-white p-6 shadow-[0_1px_3px_rgba(23,23,43,0.06)] ${className}`.trim()}
    >
      <ServiceIcon service={service} />

      <p className="mb-1 text-xs font-bold tracking-wide text-[#7C3AED]">
        {service.no}
      </p>
      <h3 className="mb-2 font-heading text-base font-bold leading-snug text-ink">
        {service.title}
      </h3>
      <p className="mb-5 flex-1 text-sm leading-relaxed text-muted line-clamp-2">
        {service.description}
      </p>

      <button
        type="button"
        aria-label={`View details: ${service.title}`}
        className="ml-auto flex h-9 w-9 items-center justify-center rounded-full border border-[#ECECF3] bg-white text-slate-700 shadow-sm transition-all duration-300 group-hover:border-transparent group-hover:bg-gradient-to-br group-hover:from-primary group-hover:to-purple group-hover:text-white"
      >
        <svg
          className="h-4 w-4"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={2.2}
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12h14" />
          <path d="M13 6l6 6-6 6" />
        </svg>
      </button>
    </article>
  );
}

export default function ServicesSection() {
  return (
    <section className="bg-white py-20">
      <div className="mx-auto max-w-[1200px] px-5">
        <h2 className="text-center font-heading text-[28px] font-bold text-ink sm:text-[32px] md:text-[36px]">
          Services
        </h2>

        {/* First 12 cards fill the 4-column grid */}
        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.slice(0, 12).map((service) => (
            <ServiceCard key={service.no} service={service} />
          ))}
        </div>

        {/* 13th card — centered in the last row, single-column width */}
        <div className="mt-6 flex justify-center">
          <ServiceCard
            service={SERVICES[12]}
            className="w-full max-w-[270px]"
          />
        </div>
      </div>
    </section>
  );
}
